#!/usr/bin/env python3
import sys


for line in sys.stdin:
    # TODO
    print('%s\t%s' % (1,line.rstrip('\n')) )
    # print('%s\t%s' % (  ,  )) pass this output to reducer
